# Hari R. S. – Portfolio

Static site. index.html plus the assets folder. No build step: push to GitHub and Netlify publishes it.

## Folder map (paths are relative to index.html)
assets/projects/  project cover images (ukki.webp, detour-society.webp, bluewhale-granite.webp, maverick-ai.webp)
assets/video/     hero-loop.mp4, hero-loop-mobile.mp4, hero-poster.webp (hero background)
                  showreel.mp4, showreel-720p.mp4, poster.webp (the full reel opened by Play)
File names are case sensitive and must not contain spaces.

## Hero background
The hero plays hero-loop.mp4 on its own (muted, looping). Phones get hero-loop-mobile.mp4. hero-poster.webp shows while it loads.
In index.html search for "ASSETS" to change the file names: hero, heroMobile, heroPoster.
Make the loop from your reel without any title text, e.g. (desktop):
  ffmpeg -ss 6.2 -t 19 -i showreel.mp4 -an -vf "crop=1824:910:0:58" -c:v libx264 -crf 27 -pix_fmt yuv420p -movflags +faststart hero-loop.mp4
Phone version: add ,scale=1440:-2 to the filter and use -crf 29.

## Play button (full reel with sound)
reel, reelMobile and reelPoster in the same ASSETS block. Make the video start fast:
  ffmpeg -i input.mp4 -c:v libx264 -crf 24 -pix_fmt yuv420p -movflags +faststart showreel.mp4

## Project covers and YouTube links
Search index.html for "PROJECTS: add your work". Change cover, role, tools and youtube on each line.

## Contact form
Netlify Forms. Add an email notification to your Gmail in the Netlify dashboard (Forms area).
